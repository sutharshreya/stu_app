Rails.application.routes.draw do
  get 'pdfs/index'

  get 'vedio/index'

  get 'aboutus/index'

  resources :resumes
  get 'gallary/index'

  resources :contact_us
  resources :registerations
  devise_for :users
  resources :collages
  resources :departments
  resources :subjects
  resources :teachers
   
  get "registerations/download_pdf" => "registerations#download_pdf", :as => 'download_pdf'

   get 'welcome/index'
 
  root 'welcome#index'
   
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
