module CollagesHelper
end
