module RegisterationsHelper
  
end
