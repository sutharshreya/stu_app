class Registeration < ApplicationRecord
  belongs_to :collage
  belongs_to :department
  
  mount_uploader :image, ImageUploader
  validates :email, :format => { :with => /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\Z/ }
  
  after_create :set_user_id
  private
  
  def set_user_id
    max_id=	Registeration.where('id = ?',Registeration.maximum(id)).pluck(:id)
    temp = max_id
    i = temp[0].to_s.rjust(4,'0')
    Registeration.where(id: max_id).update_all(user_id: i)
  
  end
  
end
   

