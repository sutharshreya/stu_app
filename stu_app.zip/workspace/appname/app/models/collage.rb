class Collage < ApplicationRecord
  belongs_to :department
end
