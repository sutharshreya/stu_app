class Department < ApplicationRecord
  belongs_to :subject
end
