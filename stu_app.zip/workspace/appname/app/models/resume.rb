class Resume < ApplicationRecord
    
    mount_uploader :file, FileUploader
     validates :name, presence: true
     
 
end
