class Teacher < ApplicationRecord
   
   attr_accessor :fname,:lname
   

end
