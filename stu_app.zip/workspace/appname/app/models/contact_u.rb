class ContactU < ApplicationRecord
end
