class VedioController < ApplicationController
  def index
  end
end
