class TeachersController < ApplicationController
  before_action :set_teacher, only: [:show, :edit, :update, :destroy]

  # GET /teachers
  # GET /teachers.json
  def index
     
    if params[:search_key].present? && params[:search_key1].blank?  
    
      @teachers=Teacher.where("tname LIKE ? ","%#{params[:search_key]}%")
    
    elsif params[:search_key1].present? && params[:search_key].blank?  
      
      @teachers=Teacher.where("qualification LIKE ? ","%#{params[:search_key1]}%")
    
    elsif params[:search_key].present? && params[:search_key1].present?  
       
      @teachers=Teacher.where("tname LIKE ? AND qualification LIKE ? ","%#{params[:search_key]}%","%#{params[:search_key1]}%")
    
    else
      
      @teachers = Teacher.all
    
    end
    
    
  end

  # GET /teachers/1
  # GET /teachers/1.json
  def show
  end

  # GET /teachers/new
  def new
    @teacher = Teacher.new
  end

  # GET /teachers/1/edit
  
  def edit
  
     
   temp = Teacher.where('id= ?',@teacher.id).pluck(:tname)
   
    
    # temp = temp.underscore.humanize.split(/\W+/)
    #   @teacher.fname = temp[0]
    #    @teacher.lname = temp[1]
     
  
    # temp[0] = fname.underscore.humanize.split(/\W+/)
    #   lname = lname.underscore.humanize.split(/\W+/)
    
    String b = temp.to_s.underscore.split('_').collect{|c| c.capitalize}.join(' ')
    
    String c = b.split
    
    String fn = c[0]
    
    # String ln = c[1]
    
    @teacher.fname = fn.underscore.humanize.split(/\W+/)
    @teacher.lname = fn.underscore.humanize.split(/\W+/)
  
 
  end

  # POST /teachers
  # POST /teachers.json
  def create
    
    String s1 = params[:teacher][:fname]
    String s2 = params[:teacher][:lname]
    
    String new_string = s1.slice(0,1).capitalize + s1.slice(1..-1)
    String new_string2 = s2.slice(0,1).capitalize + s2.slice(1..-1)
    
    params[:teacher][:tname] = new_string + new_string2
 
  
     
    @teacher = Teacher.new(teacher_params)
    

    respond_to do |format|
      if @teacher.save
        format.html { redirect_to @teacher, notice: 'Teacher was successfully created.' }
        format.json { render :show, status: :created, location: @teacher }
      else
        format.html { render :new }
        format.json { render json: @teacher.errors, status: :unprocessable_entity }
      end
    end
  end
  
   

  # PATCH/PUT /teachers/1
  # PATCH/PUT /teachers/1.json
  def update
    respond_to do |format|
      if @teacher.update(teacher_params)
        format.html { redirect_to @teacher, notice: 'Teacher was successfully updated.' }
        format.json { render :show, status: :ok, location: @teacher }
      else
        format.html { render :edit }
        format.json { render json: @teacher.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /teachers/1
  # DELETE /teachers/1.json
  def destroy
    @teacher.destroy
    respond_to do |format|
      format.html { redirect_to teachers_url, notice: 'Teacher was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_teacher
      @teacher = Teacher.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def teacher_params
      params.require(:teacher).permit(:tname, :fname , :lname ,:qualification, :created_at, :created_by, :modified_at)
    end
end
