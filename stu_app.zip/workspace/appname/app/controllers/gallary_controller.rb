class GallaryController < ApplicationController
  def index
  end
end
