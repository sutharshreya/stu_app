class AboutusController < ApplicationController
  def index
  end
end
