class RegisterationsController < ApplicationController
  before_action :set_registeration, only: [:show, :edit, :update, :destroy]

  # GET /registerations
  # GET /registerations.json
  def index
    
    if params[:search_key].present? && params[:search_key1].present? && params[:search_key2].present? && params[:search_key3].present? && params[:search_key4].present? && params[:search_key5].present?
    @registerations = Registeration.where('user_id LIKE ? AND firstname LIKE ? AND lastname LIKE ? AND email LIKE ? AND id IN (?) AND id IN (?) ',"%#{params[:search_key]}%","%#{params[:search_key1]}%","%#{params[:search_key2]}%","%#{params[:search_key3]}%",(Collage.where("cname LIKE ?","%#{params[:search_key4]}%").select("id")),(Department.where("dname LIKE ?","%#{params[:search_key5]}%").select("id")))


    elsif params[:search_key].present? || params[:search_key1].present? || params[:search_key2].present? || params[:search_key3].present? || params[:search_key4].present? || params[:search_key5].present?
    @registerations = Registeration.where('user_id LIKE ? AND firstname LIKE ? AND lastname LIKE ? AND email LIKE ? AND collage_id IN (?) AND department_id IN (?) ',"%#{params[:search_key]}%","%#{params[:search_key1]}%","%#{params[:search_key2]}%","%#{params[:search_key3]}%",(Collage.where("cname LIKE ?","%#{params[:search_key4]}%").select("id")),(Department.where("dname LIKE ?","%#{params[:search_key5]}%").select("id")))
    else
    
    @registerations = Registeration.all
    
     
    end
  end
    
  
  # GET /registerations/1
  # GET /registerations/1.json
  
  def show
    # @registeration = Registeration.find(params[:id])
    #     respond_to do |format|
    #     format.html
    #     format.pdf do
    #       pdf = CustomerPdf.new(@registeration)
    #       send_data pdf.render, filename: "User_#{id}.pdf",
    #                             type: "application/pdf",
    #                             disposition: "inline"
    #   end
    # end
    
    
    
    @registeration = Registeration.find(params[:id])
    respond_to do |format|
      format.html
          format.pdf do
            pdf = Prawn::Document.new
            table_data = Array.new
            table_data << ["UserID", "FirstName", "LastName", "Email", "Clgname","Image" ]
      
                table_data << [@registeration.user_id, @registeration.firstname, @registeration.lastname, @registeration.email,"#{Collage.where('id = ?',@registeration.collage_id).pluck(:cname)}",@registeration.image.to_s]
                 
                 
            
                pdf.table(table_data, :width => 560, :cell_style => { :inline_format => true })
                send_data pdf.render, filename: 'test.pdf', type: 'application/pdf', :disposition => 'inline'
          end
        end
 

    
    
    
  end

  # GET /registerations/new
  def new
    @registeration = Registeration.new
  end

  # GET /registerations/1/edit
  def edit
  end

  # POST /registerations
  # POST /registerations.json
  def create
    @registeration = Registeration.new(registeration_params)

    respond_to do |format|
      if @registeration.save
        format.html { redirect_to @registeration, notice: 'Registeration was successfully created.' }
        format.json { render :show, status: :created, location: @registeration }
      else
        format.html { render :new }
        format.json { render json: @registeration.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /registerations/1
  # PATCH/PUT /registerations/1.json
  def update
    respond_to do |format|
      if @registeration.update(registeration_params)
        format.html { redirect_to @registeration, notice: 'Registeration was successfully updated.' }
        format.json { render :show, status: :ok, location: @registeration }
      else
        format.html { render :edit }
        format.json { render json: @registeration.errors, status: :unprocessable_entity }
      end
      
      
    end
  end

  # DELETE /registerations/1
  # DELETE /registerations/1.json
  def destroy
    @registeration.destroy
    respond_to do |format|
      format.html { redirect_to registerations_url, notice: 'Registeration was successfully destroyed.' }
      format.json { head :no_content }
    end
  end
  
  private
    # Use callbacks to share common setup or constraints between actions.
    def set_registeration
      @registeration = Registeration.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def registeration_params
      params.require(:registeration).permit(:user_id, :firstname, :lastname, :email, :collage_id, :image, :department_id)
    end
end

