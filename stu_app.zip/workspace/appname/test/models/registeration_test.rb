require 'test_helper'

class RegisterationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
