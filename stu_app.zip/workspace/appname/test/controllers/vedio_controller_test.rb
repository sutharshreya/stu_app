require 'test_helper'

class VedioControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get vedio_index_url
    assert_response :success
  end

end
