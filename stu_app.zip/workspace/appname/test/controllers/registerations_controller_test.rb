require 'test_helper'

class RegisterationsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @registeration = registerations(:one)
  end

  test "should get index" do
    get registerations_url
    assert_response :success
  end

  test "should get new" do
    get new_registeration_url
    assert_response :success
  end

  test "should create registeration" do
    assert_difference('Registeration.count') do
      post registerations_url, params: { registeration: { collage_id: @registeration.collage_id, department_id: @registeration.department_id, email: @registeration.email, firstname: @registeration.firstname, image: @registeration.image, lastname: @registeration.lastname, user_id: @registeration.user_id } }
    end

    assert_redirected_to registeration_url(Registeration.last)
  end

  test "should show registeration" do
    get registeration_url(@registeration)
    assert_response :success
  end

  test "should get edit" do
    get edit_registeration_url(@registeration)
    assert_response :success
  end

  test "should update registeration" do
    patch registeration_url(@registeration), params: { registeration: { collage_id: @registeration.collage_id, department_id: @registeration.department_id, email: @registeration.email, firstname: @registeration.firstname, image: @registeration.image, lastname: @registeration.lastname, user_id: @registeration.user_id } }
    assert_redirected_to registeration_url(@registeration)
  end

  test "should destroy registeration" do
    assert_difference('Registeration.count', -1) do
      delete registeration_url(@registeration)
    end

    assert_redirected_to registerations_url
  end
end
