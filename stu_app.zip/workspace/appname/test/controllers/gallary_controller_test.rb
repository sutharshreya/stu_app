require 'test_helper'

class GallaryControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get gallary_index_url
    assert_response :success
  end

end
