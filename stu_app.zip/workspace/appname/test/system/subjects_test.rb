require "application_system_test_case"

class SubjectsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit subjects_url
  #
  #   assert_selector "h1", text: "Subject"
  # end
end
