require "application_system_test_case"

class ContactUsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit contact_us_url
  #
  #   assert_selector "h1", text: "ContactU"
  # end
end
