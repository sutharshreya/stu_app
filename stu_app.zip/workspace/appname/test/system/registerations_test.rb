require "application_system_test_case"

class RegisterationsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit registerations_url
  #
  #   assert_selector "h1", text: "Registeration"
  # end
end
