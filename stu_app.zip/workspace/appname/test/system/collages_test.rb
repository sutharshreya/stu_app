require "application_system_test_case"

class CollagesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit collages_url
  #
  #   assert_selector "h1", text: "Collage"
  # end
end
