require "application_system_test_case"

class ResumesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit resumes_url
  #
  #   assert_selector "h1", text: "Resume"
  # end
end
