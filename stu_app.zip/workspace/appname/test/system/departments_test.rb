require "application_system_test_case"

class DepartmentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit departments_url
  #
  #   assert_selector "h1", text: "Department"
  # end
end
