class CustomerPdf< Prawn::Document

  def initialize(registeration)
    super(page_size: "A4", page_layout: :portrait)
    @registeration = registeration

 
    
    text "• Id\- #{@registeration.user_id}", style: :italic
    text "• FirstName\- #{@registeration.firstname}", style: :italic
    text "• LastName\- #{@registeration.lastname}", style: :italic
    text "• Email\- #{@registeration.email}", style: :italic
    
 
  end

end
