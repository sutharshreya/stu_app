class CreateTeachers < ActiveRecord::Migration[5.1]
  def change
    create_table :teachers do |t|
      t.string :tname
      t.string :qualification
      t.datetime :created_at
      t.datetime :created_by
      t.datetime :modified_at

      t.timestamps
    end
  end
end
