class CreateRegisterations < ActiveRecord::Migration[5.1]
  def change
    create_table :registerations do |t|
      t.integer :user_id
      t.string :firstname
      t.string :lastname
      t.string :email
      t.belongs_to :collage, foreign_key: true
      t.string :image
      t.belongs_to :department, foreign_key: true

      t.timestamps
    end
  end
end
