class CreateCollages < ActiveRecord::Migration[5.1]
  def change
    create_table :collages do |t|
      t.string :cname
      t.belongs_to :department, foreign_key: true

      t.timestamps
    end
  end
end
